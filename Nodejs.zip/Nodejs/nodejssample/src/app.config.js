import express from 'express'
import './common/database/mongoose.db.js'
import './common/database/mysql.db.js'

const app = express()

export default app