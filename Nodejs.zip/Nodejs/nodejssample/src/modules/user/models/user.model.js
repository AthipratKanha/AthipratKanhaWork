export const Model = [
  "id",
  "name",
  "birthdate"
]

export const TableName = "users"